# Video Tutorial Script — Build & Deploy Auth System + E-Commerce API

Total length: ~25-35 minutes (you can split into 2 videos)

## Intro (0:00-0:40)
- Quick intro: who you are, what you'll build (Auth + Ecom API), tech stack.

## Setup (0:40-3:00)
- Create GitHub repo, clone, open VS Code, node init, install dependencies.
Commands:
```
git clone <repo-url>
cd auth-system
npm init -y
npm install express mongoose bcryptjs jsonwebtoken dotenv cors
```

## Build Auth System (3:00-12:00)
- Show server.js, config/db.js
- Create User model
- Implement register & login controllers (explain bcrypt + jwt)
- Create routes & middleware
- Test in Postman: register, login, protected profile

## Build E-Commerce API (12:00-22:00)
- Reuse auth code for user management
- Create Product model & controller
- Create Order model & controller
- Test adding products, placing order, viewing orders in Postman

## Deployment (22:00-28:00)
- Push code to GitHub
- Deploy to Render (show connecting repo, setting env vars)
- Show live endpoint in browser / Postman

## Closing (28:00-30:00)
- Recap features, next steps, invite to check GitHub + resume links.

Tips:
- Record terminal and VS Code with clear zoom on code.
- Keep sections short, explain concept then demo.
- Upload video on YouTube with timestamps in description.
