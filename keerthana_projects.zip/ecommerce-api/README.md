# E-Commerce Backend API

Simple e-commerce backend with authentication, products and orders.
Follow the README provided by your assistant to set up and run.
